// AUTORES
// Ernesto Fernández Parejo
// Fernando Parra Salomón

#ifndef TABLADEFIGURAS_H
#define TABLADEFIGURAS_H

#include <unordered_map>
#include <vector>
#include <string>
#include <cstring>


enum TipoFigura { F_RECTANGULO, F_CUADRADO, F_CIRCULO };

typedef char tipo_cadena[50];
struct AtributosFigura {
    int fila;
    int columna;
    int alto;
    int ancho;
    int radio;
    std::string color;
};

struct Figura {
    TipoFigura tipo;
    AtributosFigura atributos;
    tipo_cadena id;
};

typedef std::unordered_map<std::string, Figura> TF;

class TablaDeFiguras {
private:
    static const int MAX_FIGURAS = 100;
    int num_figuras;
    std::vector<std::string> ordenInsercion;

public:
    TablaDeFiguras();

    bool insertar(TF &tabla, tipo_cadena id, TipoFigura tipo, AtributosFigura atributos);
    bool getFigura(const TF &tabla, tipo_cadena id, Figura &figura);
};

#endif

