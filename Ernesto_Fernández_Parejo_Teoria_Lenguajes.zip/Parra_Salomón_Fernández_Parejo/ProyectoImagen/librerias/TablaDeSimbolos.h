// AUTORES
// Ernesto Fernández Parejo
// Fernando Parra Salomón

#ifndef TABLADESIMBOLOS_H
#define TABLADESIMBOLOS_H

#include <unordered_map>
#include <cstdio>
#include <cstring>  // para funciones de manejo de cadenas
#include <string>
#include <vector>


// Enumeración para representar los tipos de variables.
enum Tipo { T_ENTERO, T_REAL, T_LOGICO };

// Estructura que encapsula el valor de un símbolo.
// Usamos un union para ahorrar espacio, ya que sólo se usará un miembro según el tipo.
typedef char tipo_cadena[50];
struct Valor {
    union {
        int entero;
        float real;
        bool logico;
        tipo_cadena cadena; 
    };
};

// Estructura que almacena la información de un símbolo.
struct Simbolo {
    Tipo tipo;
    Valor valor;
    tipo_cadena id;
};

typedef std::unordered_map<std::string, Simbolo> TS;

class TablaDeSimbolos {
private:
    static const int MAX_IDENTIFICADORES = 100;
    int num_identificadores;
    std::vector<std::string> ordenInsercion;
public:
    TablaDeSimbolos();

    // Inserta un dato en la tabla.
    // Si el identificador no aparece, lo añade. Si ya está almacenado,
    // debe cambiar su valor comprobando que no se modifica su tipo.
    // Retorna true si se inserta o modifica correctamente.
    bool insertar(TS &tabla, tipo_cadena id, Tipo tipo, Valor valor);

    // Busca en la tabla el identificador "nombre".
    // Si se encuentra, retorna true y devuelve los datos en "simbolo".
    // tabla se pone como const porque no se modifica su valor
    bool getValor(const TS &tabla, tipo_cadena id, Simbolo &simbolo);

    void imprimir(const TS &tabla);
};

#endif // TABLADESIMBOLOS_H

