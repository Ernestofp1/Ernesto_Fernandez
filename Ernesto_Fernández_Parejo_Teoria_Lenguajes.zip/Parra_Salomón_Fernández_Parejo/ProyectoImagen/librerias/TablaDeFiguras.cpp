// AUTORES
// Ernesto Fernández Parejo
// Fernando Parra Salomón

#include "TablaDeFiguras.h"
#include <cstdio>
#include <cstring>

TablaDeFiguras::TablaDeFiguras() {}

bool TablaDeFiguras::insertar(TF &tabla, tipo_cadena id, TipoFigura tipo, AtributosFigura atributos) {
    std::string key(id);

    if (tabla.find(key) == tabla.end()) {
        if (tabla.size() >= MAX_FIGURAS) {
            fprintf(stderr, "Error: Tabla de figuras llena.\n");
            return false;
        } else {
            Figura nuevaFigura;
            nuevaFigura.tipo = tipo;
            nuevaFigura.atributos = atributos;
            strcpy(nuevaFigura.id, id);
            tabla.insert({key, nuevaFigura});
            ordenInsercion.push_back(key);
            return true;
        }
    } else {
        if (tabla.find(key)->second.tipo != tipo) {
            fprintf(stderr, "Error: No se puede cambiar el tipo de figura %s.\n", id);
            return false;
        } else {
            tabla.find(key)->second.atributos = atributos;
            return true;
        }
    }
}

bool TablaDeFiguras::getFigura(const TF &tabla, tipo_cadena id, Figura &figura) {
    std::string key(id);
    auto it = tabla.find(key);
    if (it == tabla.end()) {
        return false;
    } else {
        figura = it->second;
        return true;
    }
}

