// AUTORES
// Ernesto Fernández Parejo
// Fernando Parra Salomón

#include "TablaDeSimbolos.h"
#include <cstdio>
#include <string>

// Constructur de la tabla de símbolos.
TablaDeSimbolos::TablaDeSimbolos() {
}

bool TablaDeSimbolos::insertar(TS &tabla, tipo_cadena id, Tipo tipo, Valor valor) {
    // Se convierte el id (tipo_cadena) a std::string para usarlo en el unordered_map
    std::string key(id);

    // Se comprueba si el identificador ya existe en la tabla.
    if (tabla.find(key) == tabla.end()) { // true -> No está en la tabla
        // Se comprueba si hay espacio en la tabla.
        if (tabla.size() >= MAX_IDENTIFICADORES) {
            fprintf(stderr, "Error: Tabla de símbolos llena.\n");
            return false;
        }
        else {
            // Se añade el nuevo símbolo a la tabla.
            Simbolo nuevoSimbolo;
            nuevoSimbolo.tipo = tipo;
            nuevoSimbolo.valor = valor;
            strcpy(nuevoSimbolo.id, id);
            tabla.insert({key, nuevoSimbolo});
            ordenInsercion.push_back(key); //Para poder mostrar la tabla de simbolos ordenada por insercion
            return true;
        }

    }
    // Si se ha encontrado, hay que modificarlo
    else {
        // Si el tipo no coincide (real, entero, logico)
        if (tabla.find(key)->second.tipo != tipo) {
            fprintf(stderr, "Error: No se puede modificar el tipo de la variable %s.\n", id);
            return false;
        }
        else {
            // Se modifica el valor del símbolo.
            tabla.find(key)->second.valor = valor;
            return true;
        }

    }
}


bool TablaDeSimbolos::getValor(const TS &tabla, tipo_cadena id, Simbolo &simbolo){
    // Se convierte el id (tipo_cadena) a std::string para usarlo en el unordered_map
    std::string key(id);

    // Si no la encuentra
    if (tabla.find(key) == tabla.end()){
        return false;
    }
    else {
        simbolo = tabla.find(key)->second;
        return true;
    }

}

void TablaDeSimbolos::imprimir(const TS &tabla){
    printf("Tabla de símbolos: \n");
    for(const std::string& id : ordenInsercion){
        const Simbolo& simbolo = tabla.at(id); // usamos .at() porque ya sabemos que existe

        printf("%-10s", id.c_str());

        if (simbolo.tipo == T_ENTERO){
            printf("\t%-7s\t%i\n", "entero", simbolo.valor.entero);
        }
        else if (simbolo.tipo == T_REAL){
            printf("\t%-7s\t%f\n", "real", simbolo.valor.real);
        }
        else if (simbolo.tipo == T_LOGICO){
            printf("\t%-7s\t%s\n", "lógico", simbolo.valor.logico ? "true" : "false");
        }
        else {
            printf("\ttipo desconocido\n");
        }
    }
}
