// Traducción del lenguaje IMA
#include "imagen.h"
#include <allegro5/allegro5.h>

using namespace std;

int main(int argc, char *argv[]) {
	// Se inicia el entorno gráfico
	iniciarImagen();

	// Nueva imagen
	nuevaVentanaImagen("IMAGEN 1", 1000, 1000);
	rectanguloImagen(200, 100, 100, 100, ROJO);
	pausaImagen(0.75);
	rectanguloImagen(200, 100, 100, 100, BLANCO);
	rectanguloImagen(300, 200, 100, 100, ROJO);
	pausaImagen(1.5);
	rectanguloImagen(300, 200, 100, 100, BLANCO);
	rectanguloImagen(400, 300, 100, 100, ROJO);
	pausaImagen(2.25);
	rectanguloImagen(500, 400, 100, 100, ROJO);
	pausaImagen(0.3);
	// Pausa final de la imagen
	pausaImagen(1.5);

 	// Nueva imagen
	nuevaVentanaImagen("IMAGEN 2", 800, 800);
	circuloImagen(300, 300, 200, NARANJA);
	circuloImagen(400, 300, 200, NARANJA);
	circuloImagen(200, 300, 200, NARANJA);
	rectanguloImagen(100, 100, 200, 200, AZUL);
	pausaImagen(2.0);
	rectanguloImagen(100, 100, 200, 200, BLANCO);
	pausaImagen(1.1);
	circuloImagen(200, 300, 200, BLANCO);
	// Pausa final de la imagen
	pausaImagen(1.5);

	// Se liberan los recursos del entorno gráfico
	terminarImagen();
	return 0;
}
