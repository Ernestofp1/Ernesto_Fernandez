// Traducción del lenguaje IMA
#include "imagen.h"
#include <allegro5/allegro5.h>

using namespace std;

int main(int argc, char *argv[]) {
	// Se inicia el entorno gráfico
	iniciarImagen();

	// Nueva imagen
	nuevaVentanaImagen("IMAGEN 1", 400, 400);
	// Pausa final de la imagen
	pausaImagen(1.5);

 	// Nueva imagen
	nuevaVentanaImagen("IMAGEN 2", 800, 800);
	// Pausa final de la imagen
	pausaImagen(1.5);

	// Se liberan los recursos del entorno gráfico
	terminarImagen();
	return 0;
}
