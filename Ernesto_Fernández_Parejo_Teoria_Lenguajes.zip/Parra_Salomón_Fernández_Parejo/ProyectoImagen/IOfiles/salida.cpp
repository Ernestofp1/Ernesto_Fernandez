// Traducción del lenguaje IMA
#include "imagen.h"
#include <allegro5/allegro5.h>

using namespace std;

int main(int argc, char *argv[]) {
	// Se inicia el entorno gráfico
	iniciarImagen();

	// Nueva imagen
	nuevaVentanaImagen("LOOP", 400, 300);
	rectanguloImagen(100, 100, 40, 40, VERDE);
	pausaImagen(0.300000);
	rectanguloImagen(100, 100, 40, 40, BLANCO);
	circuloImagen(200, 200, 30, AZUL);
	pausaImagen(0.300000);
	circuloImagen(200, 200, 30, BLANCO);
	pausaImagen(0.200000);
	rectanguloImagen(100, 150, 40, 40, VERDE);
	pausaImagen(0.300000);
	rectanguloImagen(100, 150, 40, 40, BLANCO);
	circuloImagen(150, 200, 30, AZUL);
	pausaImagen(0.300000);
	circuloImagen(150, 200, 30, BLANCO);
	pausaImagen(0.200000);
	rectanguloImagen(100, 200, 40, 40, VERDE);
	pausaImagen(0.300000);
	rectanguloImagen(100, 200, 40, 40, BLANCO);
	circuloImagen(100, 200, 30, AZUL);
	pausaImagen(0.300000);
	circuloImagen(100, 200, 30, BLANCO);
	pausaImagen(0.200000);
	rectanguloImagen(100, 250, 40, 40, VERDE);
	pausaImagen(0.300000);
	rectanguloImagen(100, 250, 40, 40, BLANCO);
	circuloImagen(50, 200, 30, AZUL);
	pausaImagen(0.300000);
	circuloImagen(50, 200, 30, BLANCO);
	pausaImagen(0.200000);
	// Pausa final de la imagen
	pausaImagen(1.5);

	// Se liberan los recursos del entorno gráfico
	terminarImagen();
	return 0;
}
