/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_EXPRESIONES_IMAGEN_H_INCLUDED
# define YY_YY_EXPRESIONES_IMAGEN_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    ID_VAR = 258,                  /* ID_VAR  */
    ID_FIG = 259,                  /* ID_FIG  */
    CADENA = 260,                  /* CADENA  */
    COLOR = 261,                   /* COLOR  */
    CUADRADO = 262,                /* CUADRADO  */
    RECTANGULO = 263,              /* RECTANGULO  */
    CIRCULO = 264,                 /* CIRCULO  */
    VARIABLES = 265,               /* VARIABLES  */
    FIGURAS = 266,                 /* FIGURAS  */
    IMAGEN = 267,                  /* IMAGEN  */
    FINIMAGEN = 268,               /* FINIMAGEN  */
    PONER = 269,                   /* PONER  */
    BORRAR = 270,                  /* BORRAR  */
    PAUSA = 271,                   /* PAUSA  */
    HORIZONTAL = 272,              /* HORIZONTAL  */
    VERTICAL = 273,                /* VERTICAL  */
    TK_ENTERO = 274,               /* TK_ENTERO  */
    TK_REAL = 275,                 /* TK_REAL  */
    TK_BOOL = 276,                 /* TK_BOOL  */
    ASIGNACION = 277,              /* ASIGNACION  */
    SI = 278,                      /* SI  */
    SI_NO = 279,                   /* SI_NO  */
    REPETIR = 280,                 /* REPETIR  */
    ENTERO = 281,                  /* ENTERO  */
    REAL = 282,                    /* REAL  */
    BOOLEANO = 283,                /* BOOLEANO  */
    OR = 284,                      /* OR  */
    AND = 285,                     /* AND  */
    IGUAL = 286,                   /* IGUAL  */
    DISTINTO = 287,                /* DISTINTO  */
    MENOR = 288,                   /* MENOR  */
    MAYOR = 289,                   /* MAYOR  */
    MAYORIGUAL = 290,              /* MAYORIGUAL  */
    MENORIGUAL = 291,              /* MENORIGUAL  */
    DIVENTERO = 292,               /* DIVENTERO  */
    mas = 293,                     /* mas  */
    menos = 294,                   /* menos  */
    NOT = 295,                     /* NOT  */
    si_simple = 296                /* si_simple  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 147 "expresiones_imagen.y"

	int c_entero;
	float c_real;
	char c_cadena[25];
    	bool c_logico;
    	
	struct {
		float valor;
		bool esReal;

	} c_expresion;

#line 118 "expresiones_imagen.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_EXPRESIONES_IMAGEN_H_INCLUDED  */
