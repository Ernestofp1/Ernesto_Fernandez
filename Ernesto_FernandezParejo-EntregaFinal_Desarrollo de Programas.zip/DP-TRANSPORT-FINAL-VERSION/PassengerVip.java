
/**
 * Write a description of class PassengerVip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PassengerVip extends Passenger
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructs a VIP passenger with specific pickup and destination locations and name.
     *
     * @param pickup The pickup location, must not be null.
     * @param destination The destination location, must not be null.
     * @param name The VIP passenger's name.
     */
    public PassengerVip(Location pickup, Location destination, String name, int time, int money, Reliable reliable)
    {
        super( pickup, destination, name, time, money, reliable);
    }

    /**
     * Processes the payment by decrementing a fixed amount from the credit card for exclusive services.
     * An additional tip is added for the driver.
     */
    @Override
    public void pay() {
        // Decrementa 600 euros de la tarjeta de crédito por el viaje exclusivo
        // y añade 10 euros de propina para el conductor
        setCreditCard(getCreditCard() - 610);
    }

    /**
     * Calculates the evaluation value by doubling the input rating and adding a premium for VIP service.
     *
     * @return The enhanced evaluation value, including a VIP premium.
     */
    @Override
    public int calculateEvaluationValue(){
        return super.calculateEvaluationValue()+15;
    }

    /**
     * Provides a string representation of a VIP passenger.
     *
     * @return A string that represents the VIP passenger, including the type prefix
     * and all basic details such as name, pickup, and destination.
     */
    @Override
    public String toString(){

        return "PassengerVip" + super.toString();
    }
}
