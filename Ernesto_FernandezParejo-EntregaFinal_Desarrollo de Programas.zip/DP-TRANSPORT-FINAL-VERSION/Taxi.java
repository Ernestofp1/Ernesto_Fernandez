import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

/**
 * Model the common elements of taxis and shuttles.
 *
 * @author David J. Barnes and Michael Kölling
 * @version 2016.02.29
 * @version 2023.10.10 DP classes
 */
public abstract class Taxi {
    private final TransportCompany company;// The Taxi Company of this Taxi.
    protected Location location;// Where the vehicle is.
    private  Location targetLocation;// Where the vehicle is headed.
    private final Location origen; // Where the vehicle is created
    private int idleCount;// Record how often the vehicle has nothing to do.
    private final String name;//name of the taxi
    private int numPassenger; // numbers of passengers transported
    protected TreeSet<Passenger> passengers; // The Passengers of this Taxi.
    private ConsumoTaxi fuelConsumption;// Consumo medio de combustible
    protected int valoracion;// valoracion de cada taxi
    protected int occupation = 1;// ocupacion maxima de cada taxi

    /**
     * Constructor of class Vehicle
     * @param company The taxi company. Must not be null.
     * @param location The vehicle's starting point. Must not be null.
     * @throws NullPointerException If company or location is null.
     */
    public Taxi(TransportCompany company, Location location, String name, ConsumoTaxi consumo)
            throws NullPointerException {
        if(company == null)
            throw new NullPointerException("company");
        if(location == null)
            throw new NullPointerException("location");

        this.company = company;
        this.location = location;
        this.origen = location;
        this.targetLocation = null;
        this.idleCount = 0;
        this.name = name;
        //Ordena los passengers por su hora de llegada (arrivalTime), y en caso de empate, por su nombre
        this.passengers = new TreeSet<>(Comparator.comparing(Passenger::getArrivalTime).thenComparing(Passenger::getName));
        this.fuelConsumption = consumo;
    }

    /**
     * @return the name of the taxi
     */
    public String getName(){
        return name;
    }
    
    //Set y get de FuelConsumption
    public ConsumoTaxi getFuelConsumption(){
        return fuelConsumption;
    }
    
    public void setFuelConsumption(ConsumoTaxi fuelConsumption){
        this.fuelConsumption = fuelConsumption;
    }
    
    //Set y get de Valoracion
    public int getValoracion(){
        return this.valoracion;
    }
    
    public void setValoracion(int valoracion){
        this.valoracion = valoracion;
    }
    
    //Set y get de Occupation
    public int getOccupation(){
        return this.occupation;
    }
    
    public void setOccupation(int occupation){
        this.occupation = occupation;
    }

    /**
     *
     * @return La distancia desde el punto de origen hasta la ubicación actual.
     *
     */
    public int distanciaRecorrida(){
        return getInitialLocation().distance(getLocation());
    }

    /**
     *
     * @return La distancia origen del taxi
     *
     */
    private Location getInitialLocation() {
        return origen;
    }

    /**
     * Calcula el consumo total de combustible basado en el consumo de combustible
     * unitario y la distancia recorrida.
     *
     * @return El consumo total de combustible como un entero. Representa la cantidad total de combustible
     * consumido.
     */
    public int obtainComsumption(){
        return getFuelConsumption().getConsumo() * distanciaRecorrida();
    }

    //devuelve el pasajero del taxi actual
    public Passenger getPassenger(){
        if(!passengers.isEmpty()){
            Iterator<Passenger> it = passengers.iterator();
            return it.next();
        }
        else{
            return null;
        }
    }


    /**
     * Get the location.
     * @return Where this taxi is currently located.
     */
    public Location getLocation(){
        return location;
    }

    /**
     * Get the company
     * @return taxis company.
     */
    public TransportCompany getTaxiCompany(){
        return company;
    }

    /**
     * Set the current location.
     * @param location Where it is. Must not be null.
     * @throws NullPointerException If location is null.
     */
    public void setLocation(Location location){
        if(location != null) {
            this.location = location;
        }
        else {
            throw new NullPointerException();
        }
    }

    /**
     * Get the target location.
     * @return Where this vehicle is currently headed, or null
     *         if it is idle.
     */
    public Location getTargetLocation(){
        return targetLocation;
    }

    /**
     * Set the required target location.
     * @param location Where to go. Must not be null.
     * @throws NullPointerException If location is null.
     */
    public void setTargetLocation(Location location){
        if(location != null) {
            targetLocation = location;
        }
        else {
            throw new NullPointerException();
        }
    }

    /**
     * Receive a pickup location. This becomes the
     * target location.
     * @param location The pickup location.
     */
    public void setPickupLocation(Location location){setTargetLocation(location);}

    /**
     * Has the vehicle a target Location?
     * @return Whether this vehicle has a target Location.
     */
    public boolean hasTargetLocation(){
        return getTargetLocation() != null;
    }

    /**
     * Clear the target location.
     */
    public void clearTargetLocation(){targetLocation = null;}

    /**
     * @return on how many steps this vehicle has been idle.
     */
    public int getIdleCount(){
        return idleCount;
    }

    /**
     * @return the number of pasengers the taxi have arrived.
     */
    public int getNumPassengers(){
        return passengers.size();
    }

    /**
     * Increment the number of steps on which this vehicle
     * has been idle.
     */
    public void incrementIdleCount(){
        idleCount++;
    }

    /**
     * Return details of the taxi, such as where it is.
     * @return A string representation of the taxi.
     */
    public String toString(){
        return  getClass().getName() + " " + getName()+" at location " + getLocation() + " ocupation: "
                +occupation + " <fuel consuption: "
                + fuelConsumption.getTipo() + " (value: "+ fuelConsumption.getConsumo() +")>";
    }

    /**
     * Is the taxi free?
     * @return Free if passengers.size() > occupation.
     */
    public boolean isFree(){
        return passengers.size()<occupation;
    }

    public boolean isPassengersZero(){
        return (passengers.isEmpty());
    }

    /**
     * Notify the company of our arrival at a pickup location.
     */
    public void notifyPickupArrival(){company.arrivedAtPickup(this);}

    /**
     * Notify the company of our arrival at a passenger's destination.
     */
    public void notifyPassengerArrival(Passenger passenger){
        company.arrivedAtDestination(this, passenger);
        passenger.pay();
        valoracion += passenger.calculateEvaluationValue();
    }

    /**
     * Receive a passenger.
     * Set passenger's destination as its target location.
     * @param passenger The passenger.
     */
    public void pickup(Passenger passenger){
        targetLocation = passenger.getDestination();
        this.passengers.add(passenger); // añade un passenger al TreeSet
    }

    /**
     * Offload the passenger.
     */
    public void offloadPassenger(Passenger p){
        targetLocation = null;
        passengers.remove(p); // Elimina los pasajeros que han llegado al destino
        TreeSet<Passenger> assignedPassengers = company.getAsignacion().get(this);
        if(!company.getAsignacion().get(this).isEmpty()){
            Iterator<Passenger> iterator = assignedPassengers.iterator();
            if (iterator.hasNext()) {
                Passenger nextPassenger = iterator.next();
                setPickupLocation(nextPassenger.getRecogida());
                nextPassenger.setNombreTaxi(getName());
            }
        }
    }

    /**
     * @return how many passengers this vehicle has transported.
     */
    public int passengersTransported(){
        return numPassenger;
    }

    /**
     * Increment the number of passengers this vehicle has transported.
     */
    protected void incrementPassengersTransported(){
        numPassenger++;
    }

    /**
     * Get the distance to the target location from the current location.
     * @return distance to target location.
     */
    public int distanceToTheTargetLocation(){return location.distance(targetLocation);}

    public int distToLoc(Location loc){
        return location.distance(loc);
    }

    /**
     * Carry out a taxi's actions.
     */
    public void act(){
        if(!hasTargetLocation()){ // no tiene pasajero, no tiene destino
            incrementIdleCount(); //incrementa el tiempo parado
        }else {
            location = location.nextLocation(getTargetLocation());
            System.out.println("@@@  Taxi: " + getName() + " moving to: " + " location " + location.getX() + " - " + location.getY());
            if (location.equals(this.targetLocation)) { //si es posicion para recoger a pasajero
                setLocation(location); //guardamos la localizacion del taxi despues de hacer un movimiento
                if(getPassenger()==null) // si es nulo y y llega aqui, significa que debemos recoger un pasajero
                    notifyPickupArrival(); //notifica a la compania que es la localizacion
                else{
                    notifyPassengerArrival(getPassenger());
                    offloadPassenger(getPassenger());
                }
            }
        }
    }

    /**
     * Return details of the taxi, such as where it is.
     */
    public String showFinalInfo(){
        return  getClass().getName() + " " + getName() + " at location "
                + getLocation()
                + " ocupation: " + occupation
                + " passengers transported: "+ passengersTransported() + " - "
                + " non active for: " + getIdleCount() +
                " times - valuation: " + valoracion + " - consuption: " + obtainComsumption();
    }

    //Compara si un taxi es igual a otro
    public boolean equals(Object other){
        if(other instanceof Taxi) {
            Taxi otherTaxi = (Taxi) other;
            return name.equals(otherTaxi.getName());
        }
        else return false;
    }

}
