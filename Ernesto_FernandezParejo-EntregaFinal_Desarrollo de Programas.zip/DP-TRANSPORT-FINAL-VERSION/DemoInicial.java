import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Iterator;

/**
 * Provide a simple demonstration of running a stage-one
 * scenario. Two passengers and three taxis are created. Two pickups
 * requested. As the simulation is run, the passengers
 * should be picked up and then taken to their destination.
 *
 * @author David J. Barnes and Michael Kölling
 * @version 2016.02.29
 * @version 2023 DP Classes
 */
public class DemoInicial
{
    TransportCompany company;
    private List<Taxi> actors; //solo Taxi


    /**
     * Constructor for objects of class DemoOnePassanger
     */
    public DemoInicial() {
        company = new TransportCompany("Compañía Taxis Cáceres");
        actors = new ArrayList<>();
        reset();
    }

    /**
     * Run the demo for a fixed number of steps.
     */
    public void run() {
        /*
        Ejecutamos un número de pasos la simulación.
        En cada paso, cada taxi realiza su acción
        */
        for(int step = 0; step < 100; step++)
            step();

        showFinalInfo();
    }

    /**
     * Run the demo for one step by requesting
     * all actors to act.
     */
    public void step() {
        for(Taxi actor : actors)
            actor.act();
    }

    /**
     * Reset the demo to a starting point.
     * A single taxi and passenger are created, and a pickup is
     * requested for a single passenger.
     * @throws IllegalStateException If a pickup cannot be found
     */
    public void reset() {
        actors.clear();
        createTaxis();
        createPassengers();
        showInicialInfo();
        runSimulation();
    }

    /**
     * Taxis are created and added to the company
     */
    private void createTaxis() {
        Taxi taxi2 = new TaxiShuttle(company, new Location(10,10),"T1",
                ConsumoTaxi.LOW,2);
        Taxi taxi1 = new TaxiExclusive(company, new Location(3, 3),"T2",
                ConsumoTaxi.MEDIUM, 7000);
        Taxi taxi3 = new TaxiExclusive(company, new Location(15, 15),"T3",
                ConsumoTaxi.HIGH, 9000);

        company.addVehicle(taxi1);
        company.addVehicle(taxi2);
        company.addVehicle(taxi3);
        actors.addAll(company.getVehicles());
    }

    /**
     * Passengers are created and added to the company
     */
    private void createPassengers() {
        Passenger passenger1 = new PassengerVip(new Location(0, 0),
                new Location(2, 6),"Lucy", 30, 30000, Reliable.HIGH);
        Passenger passenger2 = new PassengerNoVip(new Location(6, 6),
                new Location(5,2),"Gru", 20, 3000, Reliable.LOW);
        Passenger passenger3 = new PassengerNoVip(new Location(10, 4),
                new Location(14,2),"Kevin", 20, 2000, Reliable.LOW);

        company.addPassenger(passenger1);
        company.addPassenger(passenger2);
        company.addPassenger(passenger3);

    }

    /**
     * A pickup is requested for a single passenger.
     * @throws IllegalStateException If a pickup cannot be found
     */
    private void runSimulation() {
        List<Passenger> passengers = company.getPassengers();

        for(Passenger passenger : passengers)
            if(!company.requestPickup(passenger))
                throw new IllegalStateException("Failed to find a pickup for: "+ passenger.getName());

    }

    /**
     * Initial info is showed with the information about taxis and passengers
     */
    private void showInicialInfo() {
        //para ordenar una colección aplicando un comparador, esta sería
        //la sintaxis (suponiendo que "passengers" es una colección donde
        //la compañía de taxis almacena los pasajero/as):

        System.out.println("--->> Simulation of the company: " + company.getName()+" <<---");
        System.out.println("-->> Taxis of the company <<--");

        //Como es un unico taxi, podemos guardar la informacion en una variable tipo taxi
        company.getVehicles().sort(Comparator.comparing(Taxi::getName));

        //muestra la informacion inicial de taxis ordenados
        for (Taxi taxi: company.getVehicles()){
            System.out.println(taxi.toString());
        }

        //muestra la informacion inicial de los pasajeros
        System.out.println("-->> Passengers requesting taxi <<--");
        company.getPassengers().sort(new Comparator<>(){
            @Override
            public int compare(Passenger p1, Passenger p2) {
                return p1.getName().compareTo(p2.getName());
            }
        });

        // ordenar y mostrar los pasajero/as
        for(Passenger passenger : company.getPassengers())
            System.out.println(passenger.toString());


        System.out.println(" ");
        System.out.println("-->> ---------------- <<--");
        System.out.println("-->> Simulation start <<--");
        System.out.println("-->> ---------------- <<--");
        System.out.println(" ");

    }

    /**
     * Final info is showed with the information about taxis and passengers
     */
    private void showFinalInfo() {

        System.out.println(" ");
        System.out.println("-->> ----------------- <<--");
        System.out.println("-->> End of simulation <<--");
        System.out.println("-->> ----------------- <<--");
        System.out.println(" ");

        System.out.println("-->> Taxis final information <<--");
        // ordenar y mostrar los taxis
        company.getVehicles().sort(new ComparadorTaxi());
        for(Taxi t:company.getVehicles())
            System.out.println(t.showFinalInfo());


        System.out.println("-->> Passengers final information <<--");
        // ordenar y mostrar los pasajero/as
        company.getPassengers().sort(new ComparadorNombrePassenger());
        for(Passenger p : company.getPassengers())
            System.out.println(p.getClass().getName() + p.showFinalInfo());

        System.out.println("-->> Taxi(s) with less time not active <<--");
        Taxi lessTime = company.getVehicles().get(0);
        for (int i = 1; i < company.getVehicles().size(); i++)
            if(company.getVehicles().get(i).getIdleCount() < company.getVehicles().get(i-1).getIdleCount()) {
                lessTime = company.getVehicles().get(i);
            }
        System.out.println(lessTime.showFinalInfo());

        System.out.println("-->> Taxi(s) with highest evaluation <<--");
        Taxi hightEval = company.getVehicles().get(0);
        for (int i = 1; i < company.getVehicles().size(); i++)
            if(company.getVehicles().get(i).getValoracion() > company.getVehicles().get(i-1).getValoracion()) {
                hightEval = company.getVehicles().get(i);
            }
        System.out.println(hightEval.showFinalInfo());
    }
}

