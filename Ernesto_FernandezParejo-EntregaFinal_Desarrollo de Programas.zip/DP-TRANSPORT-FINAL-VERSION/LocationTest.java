import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Test implementation of the Location class.
 *
 * @author Daniel Sanchez Parra
 * @version 2023.10.10 DP classes 
 */

public class LocationTest {
    Location startLocation;
    Location destination;
    Location sameAsStart;
    Location differentLocation;
    Location nullLocation;

    /**
     * Default constructor for test class LocationTest
     */
    public LocationTest() {
    }

    /**
     * Sets up the test fixture.
     * Called before every test case method.
     */
    @Before
    public void setUp() {
        startLocation = new Location(1, 2);
        destination = new Location(2, 5);
        sameAsStart = new Location(1, 2);
        differentLocation = new Location(3, 4);
        nullLocation = null;
    }

    /**
     * Tears down the test fixture.
     * Called after every test case method.
     */
    @After
    public void tearDown() {
    }

    /**
     * Test the distance method of the Location class.
     */
    @Test
    public void testDistance() {
        assertEquals(5, startLocation.distance(new Location(5, 7)));
        assertEquals(3, startLocation.distance(destination));
        // Utilizando otra aserción:
        assertTrue(startLocation.distance(destination) == 3);
    }

    /**
     * Run tests of the nextLocation method of the Location class.
     */
    @Test
    public void testAdjacentLocations() {
        // Testear la adyacencia entre dos localizaciones. Se puede hacer
        // utilizando llamada al método "nextLocation".
        assertEquals(new Location(2, 3), startLocation.nextLocation(destination));
        startLocation = startLocation.nextLocation(destination);
        assertEquals(new Location(2, 4), startLocation.nextLocation(destination));
        startLocation = startLocation.nextLocation(destination);
        assertEquals(new Location(2, 5), startLocation.nextLocation(destination));
        startLocation = startLocation.nextLocation(destination);
        assertEquals(new Location(2, 5), startLocation.nextLocation(destination));
    }

    /**
     * Test the equals method of the Location class.
     */
    @Test
    public void testEquals() {
        assertTrue(startLocation.equals(sameAsStart));
        assertFalse(startLocation.equals(differentLocation));
        assertFalse(startLocation.equals(nullLocation));
        assertFalse(startLocation.equals(new Object()));
    }

    /**
     * Test the getX method of the Location class.
     */
    @Test
    public void testGetX() {
        assertEquals(1, startLocation.getX());
        assertEquals(2, destination.getX());
    }

    /**
     * Test the getY method of the Location class.
     */
    @Test
    public void testGetY() {
        assertEquals(2, startLocation.getY());
        assertEquals(5, destination.getY());
    }

    /**
     * Test the toString method of the Location class.
     */
    @Test
    public void testToString() {
        assertEquals("1,2", startLocation.toString());
        assertEquals("2,5", destination.toString());
    }

    /**
     * Test the hashCode method of the Location class.
     */
    @Test
    public void testHashCode() {
        assertEquals(startLocation.hashCode(), sameAsStart.hashCode());
        assertNotEquals(startLocation.hashCode(), differentLocation.hashCode());
    }
}
