import java.util.Comparator;
/**
 * Write a description of class ComparadorDistancia here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ComparadorDistancia implements Comparator<Taxi>
{
    private Location lo;
    public ComparadorDistancia (Location loc){
        lo = loc;
    }
    public int compare(Taxi t1, Taxi t2){
        double dist1 = t1.distToLoc(lo);
        double dist2 = t2.distToLoc(lo);

        // Considera la precisión de punto flotante al comparar distancias
        final double EPSILON = 1E-10; // Define un pequeño rango para considerar valores iguales
        if (Math.abs(dist1 - dist2) < EPSILON) {
            return t1.getName().compareTo(t2.getName()); // Orden alfabético si las distancias son iguales
        } else if (dist1 > dist2) {
            return 1;
        } else {
            return -1;
        }
    }
}
