import java.util.TreeSet;

public class TaxiShuttle extends Taxi{

    /**
     * Constructor of class Vehicle
     *
     * @param company  The taxi company. Must not be null.
     * @param location The vehicle's starting point. Must not be null.
     * @param name
     * @throws NullPointerException If company or location is null.
     */
    public TaxiShuttle(TransportCompany company, Location location, String name, ConsumoTaxi consumo,int occupation)
            throws NullPointerException {
        super(company, location, name, consumo);
        this.occupation = occupation;

    }

}
