import java.util.List;
import java.util.TreeSet;

/**
 * Model a passenger wishing to get from one
 * location to another.
 *
 * @author David J. Barnes and Michael Kölling
 * @version 2016.02.29
 * @version 2023.10.10 DP classes
 */
//public abstract class Passenger
public abstract class Passenger extends TreeSet<Passenger> {
    private final String name; //nombre
    private final Location pickup; //localizacion del pasajero
    private final Location destination; //destino del pasajero
    private String taxiName; //taxi que ha usado
    private int arrivalTime; //hora en la que el pasajero/a debería llegar a su destino
    private int creditCard; //dinero que tiene en la tarjeta de crédito
    private Reliable reliable; //representa la fiabilidad de un pasajero/a

    /**
     * Constructor for objects of class Passenger
     *
     * @param pickup      The pickup location, must not be null.
     * @param destination The destination location, must not be null.
     * @param name        The passenger's name
     * @throws NullPointerException If either location is null.
     */
    public Passenger(Location pickup, Location destination, String name, int arrivalTime, int money, Reliable reliable)
    {
        if(pickup == null) {
            throw new NullPointerException("Pickup location");
        }
        if(destination == null) {
            throw new NullPointerException("Destination location");
        }
        this.pickup = pickup;
        this.destination = destination;
        this.name = name;
        this.taxiName="Sin taxi";
        this.creditCard = money;
        this.arrivalTime = arrivalTime;
        this.reliable = reliable;
    }

    /**
     * @return The name of the passenger.
     */
    public String getName()
    {
        return name;
    }

    /**
     * @return urn The destination location.
     */
    public Location getDestination()
    {
        return destination;
    }

    /**
     * Return details of the passenger, such as where it is.
     * @return A string representation of the passenger.
     */
    public String toString() {
        return " " + getName()+" travelling from location " + pickup + " to location " + destination + " arrival time: "
                + arrivalTime + " money in the credit card: " + creditCard + " "
                + reliable.toString();
    }

    /**
     * Devuelve la ubicación de recogida del pasajero.
     *
     * @return Location donde el pasajero fue recogido.
     */
    public Location getRecogida(){
        return pickup;
    }

    /**
     * Modifica el nombre del taxi asignado al pasajero.
     *
     * @param nameTaxi El nuevo nombre del taxi.
     */
    public void setNombreTaxi(String nameTaxi){
        this.taxiName = nameTaxi;
    }

    /**
     * Devuelve el nombre del taxi asignado al pasajero.
     *
     * @return String nombre del taxi.
     */
    public String getNombreTaxi(){
        return taxiName;
    }

    /**
     * Devuelve el tiempo de llegada del pasajero.
     *
     * @return int tiempo de llegada.
     */

    public int getArrivalTime() {return arrivalTime;}

    /**
     * Establece el tiempo de llegada del pasajero.
     *
     * @param arrivalTim Nuevo tiempo de llegada.
     */
    public void setArrivalTime(int arrivalTim){this.arrivalTime = arrivalTim;}

    /**
     * Devuelve el dinero del pasajero.
     *
     * @return int número de la tarjeta de crédito.
     */
    public int getCreditCard() {return creditCard;}

    /**
     * Establece el dinero del pasajero.
     *
     * @param creditCard Nueva cantidad de dinero
     */
    public void setCreditCard(int creditCard){this.creditCard = creditCard;}

    /**
     * Devuelve el indicador de confiabilidad del pasajero.
     *
     * @return Reliable indicador de confiabilidad.
     */
    public Reliable getReliable(){
        return reliable;
    }

    /**
     * Establece el indicador de confiabilidad del pasajero.
     *
     * @param reliable Nuevo indicador de confiabilidad.
     */
    public void setReliable(Reliable reliable){this.reliable = reliable;}

    /**
     * Método abstracto para realizar el pago al vehículo utilizado.
     * Implementado por clases derivadas.
     */
    public abstract void pay();

    /**
     * Calcula un valor de evaluación multiplicando la valoración dada por dos.
     *
     * @return int valor calculado.
     */
    public int calculateEvaluationValue (){
        return 2*this.reliable.getValor();
    }

    /**
     * Devuelve información final sobre el pasajero, incluyendo el nombre del taxi utilizado.
     *
     * @return String información detallada del pasajero.
     */
    public String showFinalInfo() {
        return " " + name + " in location " + destination +
                " transported by: " + taxiName + " with " + creditCard + " in the credit card";
    }

    /**
     * Compara si este objeto Passenger es igual a otro objeto.
     *
     * @param other Objeto con el cual comparar.
     * @return boolean true si ambos objetos son pasajeros con el mismo nombre, false de otra forma.
     */
    public boolean equals(Object other){
        if(other instanceof Passenger) {
            Passenger otherPassenger = (Passenger) other;
            return this.name.equals(otherPassenger.getName());
        }
        else return false;
    }

}
