import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class TaxiTest.
 *
 * @author  David J. Barnes and Michael Kölling
 * @version 2016.02.29
 * @version 2023.10.10 DP classes
 */
public class TaxiTest
{
    private Taxi taxi1,taxi2;
    private Passenger passenger;
    TransportCompany company;
    Location taxiLocation;
    Location pickup;
    Location destination;
    private ConsumoTaxi consumoTaxi;

    /**
     * Default constructor for test class TaxiTest
     */
    public TaxiTest()
    {

    }

    /**
     * Create a taxi.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        company = new TransportCompany("Compañía Taxis Cáceres");
        // Starting position for the taxi.
        taxiLocation = new Location(7, 7);
        // Locations for the passenger.
        pickup = new Location(1, 2);
        destination = new Location(5, 6);

        passenger = new PassengerVip(pickup, destination,"Kevin",10,100,Reliable.LOW);
        taxi1 = new TaxiExclusive(company, taxiLocation, "T1", consumoTaxi,500) ;
        taxi2 = new TaxiShuttle(company, taxiLocation, "T2", consumoTaxi, 3);

        // Añadir taxis a la compañía
        company.addVehicle(taxi1);
        company.addVehicle(taxi2);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Test creation and the initial state of a taxi.
     */
    @Test
    public void testCreation()
    {
        assertEquals(taxi1.getName(),"T1");
        assertEquals(taxi1.getTaxiCompany(),company);
        assertEquals(taxi1.getLocation(),taxiLocation);
        assertTrue(taxi1.isFree());
    }

    /**
     * Test that a taxi is no longer free after it has
     * picked up a passenger.
     */
    @Test
    public void testPickup()
    {
        taxi1.pickup(passenger);
        assertEquals(destination, taxi1.getTargetLocation());
        assertEquals(1, taxi1.getNumPassengers());
        assertFalse(taxi1.isFree());
    }

    /**
     * Test that a taxi becomes free again after offloading
     * a passenger.
     */
    @Test
    public void testOffload()
    {
        company.getAsignacion().put(taxi1, taxi1.passengers);
        taxi1.pickup(passenger);
        //vemos que el taxi no está libre
        assertFalse(taxi1.isFree());
        //dejamos al pasajero
        taxi1.offloadPassenger(taxi1.getPassenger());
        //verificamos que el taxi está libre
        assertTrue(taxi1.isPassengersZero());
    }

    /**
     * Test that a taxi picks up and delivers a passenger within
     * a reasonable number of steps.
     */
    @Test
    public void testDelivery()
    {
        company.getAsignacion().put(taxi1, taxi1.passengers);
        company.getAsignacion().get(taxi1).add(passenger);
        int cont = 0;
        while (taxi1.isFree()) {
            taxi1.act();
            cont++;
        }
        while (!taxi1.isFree()) {
            taxi1.act();
            cont++;
        }
        assertTrue(taxi1.isFree());
        // El límite de pasos razonables será 15
        assertTrue(cont <= 15);
    }
}


