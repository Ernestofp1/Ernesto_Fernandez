import java.util.*;
import java.util.TreeSet;
/**
 * Model the operation of a taxi company, operating different
 * types of vehicle. This version operates a single taxi.
 *
 * @author David J. Barnes and Michael Kölling
 * @version 2016.02.29
 */
public class TransportCompany
{
    private final String name;  //nombre de la compañía
    private final ArrayList <Taxi> vehiculos;
    private final ArrayList <Passenger> pasajeros;

    //Es un map donde se asocia a cada objeto taxi, un treeSet de pasajeros
    private final Map<Taxi, TreeSet<Passenger>>  asignaciones;

    /**
     * Constructor for objects of class TransportCompany
     */
    public TransportCompany(String name)
    {
        this.name = name;
        this.vehiculos = new ArrayList <> ();
        this.pasajeros = new ArrayList <> ();
        this.asignaciones = new HashMap<>();
    }

    /**
     * Constructor for objects of class TransportCompany
     */
    public TransportCompany(String name, ArrayList <Taxi> vehiculo,  ArrayList <Passenger> pasajeros,
                            Map<Taxi, TreeSet<Passenger>> asignaciones_)
    {
        this.name = name;
        this.vehiculos = vehiculo;
        this.pasajeros = pasajeros;
        this.asignaciones = asignaciones_;
    }

    /**
     * @return The name of the company.
     */
    public String getName()
    {
        return name;
    }

    /**
     * A vehicle has arrived at a passenger's destination.
     * @param vehicle The vehicle at the destination.
     * @param passenger The passenger being dropped off.
     */
    public void arrivedAtDestination(Taxi vehicle, Passenger passenger) {
        System.out.println(">>>> " + vehicle.getClass().getName() + " " + vehicle.getName()+ " at location " +
                vehicle.getLocation() + " ocupation: "
                + vehicle.getOccupation()  + " offloads " + passenger);
        asignaciones.get(vehicle).remove(passenger);
    }

    /**
     * @return The list of vehicles.
     */
    public List<Taxi> getVehicles()
    {
        return this.vehiculos;
    }

    /**
     * @return The list of passengers.
     */
    public List<Passenger> getPassengers()
    {
        return this.pasajeros;
    }

    /**
     * @return The list of assigment.
     */
    public Map<Taxi, TreeSet<Passenger>> getAsignacion()
    {
        return this.asignaciones;
    }

    /**
     * @param vehicle Adds the new Vehicle.
     */
    public void addVehicle(Taxi vehicle)
    {
        this.vehiculos.add(vehicle);
    }

    /**
     * Add a new passenger in the company.
     * @param passenger The new passenger.
     */
    public void addPassenger(Passenger passenger)
    {
        this.pasajeros.add(passenger);
    }

    /**
     * Add a new passenger in the company.
     * @param asignacion The new passenger.
     */
    public void addAsignacion(Map<Taxi, TreeSet<Passenger>> asignacion) {
        this.asignaciones.put((Taxi) asignacion.keySet(), asignacion.get(asignacion.keySet()));
    }

    /**
     * Find a passenger the most closed free vehicle to a location, if any.
     * @param location location to go
     * @return A free vehicle, or null if there is none.
     */
    private Taxi scheduleVehicle(Location location, String tipoTaxi, Passenger p) {
        vehiculos.sort(new ComparadorDistancia(location));
        Taxi taxi = null;
        boolean flag = true;
        Iterator <Taxi> iteratorTaxi = vehiculos.iterator();
        while(iteratorTaxi.hasNext() && flag ){
            taxi = iteratorTaxi.next();
            if(taxi.isFree() && taxi.getClass().getName().equals(tipoTaxi)){
                if(p.getCreditCard() > 20000) {
                    if(taxi.getOccupation() == 1 &&taxi.getOccupation() > taxi.passengersTransported()) {
                        flag = false;
                    }
                } else{
                    if(taxi.getOccupation() > taxi.passengersTransported())
                        flag=false;
                }
            }
        }
        return taxi;
    }

    /**
     * Request a pickup for the given passenger.
     * @param passenger The passenger requesting a pickup.
     * @return Whether a free vehicle is available.
     */
    public boolean requestPickup(Passenger passenger) {
        Taxi t;

        if(passenger.getClass().getName().equals("PassengerVip"))
            t = scheduleVehicle(passenger.getRecogida(), "TaxiExclusive",passenger);
        else
            t = scheduleVehicle(passenger.getRecogida(), "TaxiShuttle",passenger);

        if(t != null){
            t.setPickupLocation(passenger.getRecogida());
            passenger.setNombreTaxi(t.getName());
            t.incrementPassengersTransported();
            if(asignaciones.containsKey(t))
                asignaciones.get(t).add(passenger);
            else{
                TreeSet<Passenger> passengersAssig =new TreeSet<>(Comparator.comparing(Passenger::getArrivalTime).thenComparing(Passenger::getName));
                passengersAssig.add(passenger);
                asignaciones.put(t,passengersAssig);
            }
            System.out.println("<<<< "+ t.getClass().getName() + " " + passenger.getNombreTaxi() +  " at location "
                    + t.getLocation() + " occuation " + t.getOccupation() +  " go to pick up passenger " + passenger.getName()
                    + " at location " + passenger.getRecogida());
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * A vehicle has arrived at a pickup point.
     * @param taxi The vehicle at the pickup point.
     */
    public void arrivedAtPickup(Taxi taxi) {
        TreeSet<Passenger> passengersAssig = asignaciones.get(taxi);
        if (passengersAssig.isEmpty())
            System.out.println("No se ha encontrado pasajero en el taxi");
        else {
            Passenger p = passengersAssig.pollFirst(); // Obtiene y remueve el primer pasajero del conjunto
            if (p != null) {
                taxi.pickup(p);
                p.setNombreTaxi(taxi.getName());
                System.out.println("<<<< " + taxi.getClass().getName() + " " + taxi.getName()
                        + " at location " + taxi.getLocation() + " occupation " + taxi.getOccupation()
                        + " picks up " + p.getName());
            }
        }
    }

}
