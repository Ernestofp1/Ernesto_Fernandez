
/**
 * Write a description of class PassengerNoVip here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PassengerNoVip extends Passenger {

    /**
     * Constructs a non-VIP passenger with specific pickup and destination locations and name.
     *
     * @param pickup The pickup location, must not be null.
     * @param destination The destination location, must not be null.
     * @param name The non-VIP passenger's name.
     */
    public PassengerNoVip(Location pickup, Location destination, String name, int time, int money, Reliable reliable) {
        // initialise instance variables
        super(pickup, destination, name, time, money, reliable);
    }

    /**
     * Processes the payment by decrementing a smaller fixed amount from the credit card, suitable for non-VIP services.
     */
    public void pay(){
        setCreditCard(getCreditCard() - 30);
    }

    @Override
    public String toString(){

        return "PassengerNoVip" + super.toString();
    }
}
