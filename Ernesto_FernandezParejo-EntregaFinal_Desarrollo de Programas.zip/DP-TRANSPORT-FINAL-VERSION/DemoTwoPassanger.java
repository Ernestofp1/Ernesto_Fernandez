import java.util.*;

/**
 * Provide a simple demonstration of running a stage-one
 * scenario. A single passenger and taxi are created, and a pickup
 * requested. As the simulation is run, the passenger
 * should be picked up and then taken to their destination.
 *
 * @author David J. Barnes and Michael Kölling
 * @version 2016.02.29
 * @version 2023 DP Classes
 */
public class DemoTwoPassanger
{
    TransportCompany company;
    private List<Taxi> actors;


    /**
     * Constructor for objects of class DemoOnePassanger
     */
    public DemoTwoPassanger()
    {
        company = new TransportCompany("Compañía Taxis Cáceres");
        actors = new ArrayList<>();
        reset();
    }

    /**
     * Run the demo for a fixed number of steps.
     */
    public void run() {
        /*
        Ejecutamos un número de pasos la simulación.
        En cada paso, cada taxi realiza su acción
        */
        for(int step = 0; step < 100; step++)
            step();

        showFinalInfo();
    }

    /**
     * Run the demo for one step by requesting
     * all actors to act.
     */
    public void step() {
        for(Taxi actor : actors)
            actor.act();

    }

    /**
     * Reset the demo to a starting point.
     * A single taxi and passenger are created, and a pickup is
     * requested for a single passenger.
     * @throws IllegalStateException If a pickup cannot be found
     */
    public void reset() {
        actors.clear();
        createTaxis();
        createPassengers();
        showInicialInfo();
        runSimulation();
    }

    /**
     * Taxis are created and added to the company
     */
    private void createTaxis() {
        /* TODO weight a cambiar */
        Taxi taxi1 = new TaxiExclusive(company, new Location(10, 10),"T1",ConsumoTaxi.MEDIUM, 7000);
        Taxi taxi2 = new TaxiShuttle(company, new Location(8,8),"T2",ConsumoTaxi.LOW,2);

        company.addVehicle(taxi1);
        company.addVehicle(taxi2);
        actors.addAll(company.getVehicles());

    }

    /**
     * Passengers are created and added to the company
     */
    private void createPassengers() {
        Passenger passenger1 = new PassengerVip(new Location(6, 6),
                new Location(5, 2),"Lucy", 30, 30000, Reliable.HIGH);
        Passenger passenger2 = new PassengerNoVip(new Location(2, 3),
                new Location(3,10),"Gru",20, 2000, Reliable.LOW);

        company.addPassenger(passenger1);
        company.addPassenger(passenger2);

    }

    /**
     * A pickup is requested for a single passenger.
     * @throws IllegalStateException If a pickup cannot be found
     */
    private void runSimulation() {
        List<Passenger> passengers = company.getPassengers();

        for(Passenger p : passengers)
            if(!company.requestPickup(p))
                throw new IllegalStateException("Failed to find a pickup for: "+ p.getName());

    }

    /**
     * Initial info is showed with the information about taxis and passengers
     */
    private void showInicialInfo() {

        System.out.println("--->> Simulation of the company: " + company.getName()+" <<---");
        System.out.println("-->> Taxis of the company <<--");

        //Como es un unico taxi, podemos guardar la informacion en una variable tipo taxi
        company.getVehicles().sort(Comparator.comparing(Taxi::getName));

        //muestra la informacion inicial de taxis ordenados
        for (Taxi taxi: company.getVehicles()){
            System.out.println(taxi.toString());
        }

        System.out.println("-->> Passengers requesting taxi <<--");
/*
        *ordenar y mostrar los pasajero/as
        *para ordenar una colección aplicando un comparador, esta sería
        *la sintaxis (suponiendo que "passengers" es una colección donde
        *la compañía de taxis almacena los pasajero/as):
        *Collections.sort(passenger, new ComparadorNombrePassenger());
        *Como es un unico passenger, podemos guardar la informacion en una variable tipo passenger
*/
        company.getPassengers().sort(Comparator.comparing(Passenger::getName));

        for(Passenger passenger : company.getPassengers())
            System.out.println(passenger.toString());


        System.out.println(" ");
        System.out.println("-->> ---------------- <<--");
        System.out.println("-->> Simulation start <<--");
        System.out.println("-->> ---------------- <<--");
        System.out.println(" ");
    }

    /**
     * Final info is showed with the information about taxis and passengers
     */
    private void showFinalInfo() {

        System.out.println(" ");
        System.out.println("-->> ----------------- <<--");
        System.out.println("-->> End of simulation <<--");
        System.out.println("-->> ----------------- <<--");
        System.out.println(" ");

        System.out.println("-->> Taxis final information <<--");
        // ordenar y mostrar los taxis
        company.getVehicles().sort(new ComparadorTaxi());
        for(Taxi t:company.getVehicles()){
            System.out.println(t.showFinalInfo());
        }

        System.out.println("-->> Passengers final information <<--");
        // ordenar y mostrar los pasajero/as
        company.getPassengers().sort(new ComparadorNombrePassenger());
        for(Passenger p : company.getPassengers())
            System.out.println(p.getClass().getName() + p.showFinalInfo());


        System.out.println("-->> Taxi(s) with less time not active <<--");
        Taxi lessTime = company.getVehicles().get(0);
        for (int i = 1; i < company.getVehicles().size(); i++)
            if(company.getVehicles().get(i).getIdleCount() < company.getVehicles().get(i-1).getIdleCount()) {
                lessTime = company.getVehicles().get(i);
            }
        System.out.println(lessTime.showFinalInfo());


        System.out.println("-->> Taxi(s) with highest evaluation <<--");
        Taxi hightEval = company.getVehicles().get(0);
        for (int i = 1; i < company.getVehicles().size(); i++)
            if(company.getVehicles().get(i).getValoracion() > company.getVehicles().get(i-1).getValoracion()) {
                hightEval = company.getVehicles().get(i);
            }
        System.out.println(hightEval.showFinalInfo());

    }

}
