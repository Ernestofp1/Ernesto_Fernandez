/**
 * Enumeración para representar los niveles de consumo de combustible de un taxi.
 * Define tres niveles de consumo: ALTO, MEDIO y BAJO, cada uno con un valor asociado
 * que representa el consumo de combustible en una escala cuantitativa.
 */
public enum ConsumoTaxi {
    HIGH("HIGH", 8),
    MEDIUM("MEDIUM", 6),
    LOW("LOW", 4);
    private final String tipo;
    private final int consumo;

    /**
     * Constructor privado para la enumeración ConsumoTaxi.
     *
     * @param tipo Descripción del tipo de consumo de combustible.
     * @param consumo Valor entero que representa el consumo de combustible.
     */
    ConsumoTaxi(String tipo, int consumo) {
        this.tipo = tipo;
        this.consumo = consumo;
    }

    /**
     * Obtiene la descripción del tipo de consumo de combustible.
     *
     * @return String que representa el tipo de consumo.
     */
    public String getTipo(){
        return tipo;
    }

    /**
     * Obtiene el valor del consumo de combustible asociado al tipo.
     *
     * @return int que representa el valor del consumo de combustible.
     */
    public int getConsumo(){
        return consumo;
    }

    /**
     * Proporciona una representación en cadena de texto del objeto ConsumoTaxi.
     * Formato de la representación: "< fuel consumption: tipo(value:consumo)>".
     *
     * @return String representando la descripción textual del nivel de consumo.
     */
    @Override
    public String toString() {
        return "< fuel consumption: " + tipo + "(value:" + consumo +")>";
    }
}
