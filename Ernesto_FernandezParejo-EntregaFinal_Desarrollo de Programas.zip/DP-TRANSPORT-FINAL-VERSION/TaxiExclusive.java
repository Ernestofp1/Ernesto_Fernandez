import java.util.TreeSet;

public class TaxiExclusive extends Taxi{

    private double weight; // Peso del objeto
    private int popularity; // Popularidad en redes sociales

    /**
     * Constructor of class Vehicle
     *
     * @param company  The taxi company. Must not be null.
     * @param location The vehicle's starting point. Must not be null.
     * @param name
     * @throws NullPointerException If company or location is null.
     */
    public TaxiExclusive(TransportCompany company, Location location, String name,ConsumoTaxi consumo,
                         double weight) throws NullPointerException {
        super(company, location, name,consumo);
        this.weight = weight;
        this.popularity = 6;
    }

    /**
     * Get the weight of the taxi.
     * @return The weight of the taxi.
     */
    public double getWeight() {return weight;}

    /**
     * Set the weight of the taxi.
     * @param weight The weight to set.
     */
    public void setWeight(double weight) {this.weight = weight;}

    /**
     * Get the current popularity of the taxi on social networks.
     * @return The popularity score.
     */
    public int getPopularity() {return popularity;}

    /**
     * Set the popularity of the taxi.
     * @param popularity The popularity score to set.
     */
    public void setPopularity(int popularity) {this.popularity = popularity;}

    /**
     * Calculate the fuel consumption based on the weight of the taxi, average fuel consumption, and the distance traveled.
     * @return The total fuel consumption.
     */
    @Override
    public int obtainComsumption() {
        return (int) (super.obtainComsumption()*(this.weight/2));
    }

    /**
     * Actualiza la popularidad en redes basada en el saldo de la tarjeta del pasajero.
     * Si el saldo de la tarjeta de crédito del pasajero es superior a 20,000, incrementa
     * la popularidad del taxi en 4 puntos. Si no, disminuye la popularidad en 1 punto.
     *
     * @param passenger El pasajero actual en el taxi.
     */
    private void updatePopularity(Passenger passenger) {
        if (passenger.getCreditCard() > 20000)
            popularity += 4;
        else
            popularity -= 1;
    }

    public void notifyPassengerArrival(Passenger passenger){
        super.notifyPassengerArrival(passenger);
        updatePopularity(passenger);
    }

    /**
     * Retorna una cadena de texto con la información final del taxi, incluyendo su popularidad.
     * Esta información se basa en la obtenida de la clase padre y añade detalles sobre la
     * popularidad del taxi.
     *
     * @return String representando la información final del taxi con la popularidad.
     */
    public String showFinalInfo(){
        return  super.showFinalInfo() + " - popularity: " + this.popularity;
    }

}
