package usuario;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import pcd.unex.StockServiceGrpc;
import pcd.unex.StockServiceGrpc.StockServiceBlockingStub;
import pcd.unex.StockServiceGrpc.StockServiceImplBase;
import pcd.unex.StockServiceGrpc.StockServiceStub;
import pcd.unex.StockServiceOuterClass.RestoProductoReply;
import pcd.unex.StockServiceOuterClass.VentaRequest;
import pcd.util.Ventana;

public class MiUsuario {
	private final ManagedChannel channel;
	private final StockServiceBlockingStub blockingStub;
	
	private final StockServiceStub assyncStub;
	
	private final Ventana v;
	
	public MiUsuario(String host, int port){
		this.channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();
		
		this.assyncStub = StockServiceGrpc.newStub(channel);
		
		this.blockingStub = StockServiceGrpc.newBlockingStub(channel);
		
		this.v = new Ventana("Cliente", 350, 30);
	}
	
	public void ejecutarRegistrarVenta (String id, int cantidad) {
		VentaRequest sol = VentaRequest.newBuilder().setIdProducto(id).setCantidad(cantidad).build();
		
		RestoProductoReply res = this.blockingStub.registrarVenta(sol);
		
		this.v.addText("Del producto " + id + " hay: " + res.getResto());
		
	}
    
}
