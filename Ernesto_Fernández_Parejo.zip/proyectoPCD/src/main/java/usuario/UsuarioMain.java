package usuario;

import java.util.Iterator;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import pcd.unex.StockServiceGrpc;
import pcd.unex.StockServiceOuterClass.ProductosReply;
import pcd.unex.StockServiceOuterClass.StockRequest;
import pcd.unex.StockServiceGrpc.StockServiceBlockingStub;
import pcd.util.Ventana;

public class UsuarioMain {

	public static void main(String[] args) {
		Ventana v = new Ventana("Bajo stock", 350, 50);
		
		ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9093).usePlaintext().build();
		
		StockServiceBlockingStub stub = StockServiceGrpc.newBlockingStub(channel);
		
		StockRequest sol = StockRequest.newBuilder().setUmbral(65).build();
		
		Iterator <ProductosReply> replies = stub.bajoStock(sol);
		
		v.addText ("Productos con bajo stock: \n");
		
		while (replies.hasNext()) {
			ProductosReply res = replies.next();
			System.out.println("Producto: " + res.getIdProducto());
		}

		channel.shutdown();
	}

}
