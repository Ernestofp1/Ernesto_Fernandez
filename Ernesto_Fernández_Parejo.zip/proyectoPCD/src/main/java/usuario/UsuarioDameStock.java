package usuario;

import java.util.ArrayList;
import java.util.List;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;
import pcd.unex.StockServiceGrpc;
import pcd.unex.StockServiceGrpc.StockServiceStub;
import pcd.unex.StockServiceOuterClass.DameStockReply;
import pcd.unex.StockServiceOuterClass.DameStockRequest;
import pcd.util.Ventana;

public class UsuarioDameStock {

	public static void main(String[] args) {
		ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9093).usePlaintext().build();
		StockServiceStub assyncStub = StockServiceGrpc.newStub(channel);
		
		Ventana v = new Ventana("Dame stock", 350, 50);
		
		StreamObserver<DameStockRequest> requestObserver = assyncStub.dameStockR(new StreamObserver<DameStockReply>() {
			@Override
			public void onNext(DameStockReply value) {
				v.addText("Producto: " + value.getIdProducto() + " quedan " + value.getCantidad());
			}

			@Override
			public void onError(Throwable t) {
				v.addText("Error: " + t.getMessage());
				}

			@Override
			public void onCompleted() {
				v.addText("Finalizando el servicio de stock");
                			}
		});
		
		List<String> idProductos = new ArrayList<String>();
		
		idProductos.add("0");
		idProductos.add("1");
		idProductos.add("2");
		
		for (String id : idProductos) {
			DameStockRequest request = DameStockRequest.newBuilder().setIdProducto(id).build();
			requestObserver.onNext(request);
		}
		
		requestObserver.onCompleted();
		channel.shutdown();
	}

}
