package servicio;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import delivery.Config;
import io.grpc.stub.StreamObserver;
import pcd.unex.StockServiceGrpc.StockServiceImplBase;
import pcd.unex.StockServiceOuterClass.DameStockReply;
import pcd.unex.StockServiceOuterClass.DameStockRequest;
import pcd.unex.StockServiceOuterClass.ProductosReply;
import pcd.unex.StockServiceOuterClass.RestoProductoReply;
import pcd.unex.StockServiceOuterClass.StockRequest;
import pcd.unex.StockServiceOuterClass.VentaRequest;
import pcd.util.Ventana;

public class MiServicio extends StockServiceImplBase{
	
	private final Ventana v;
	
	ConcurrentHashMap<String,Integer> mapaProductos;
	
	public MiServicio(Ventana v) {
		this.v = v;
		//Llenamos  el mapa con stock de 100 para cada producto.
		this.mapaProductos = new ConcurrentHashMap<String, Integer>();
		for(int i = 0; i < Config.maximoIdProducto; i++) {
			this.mapaProductos.put(Integer.toString(i), 100);
		}
	}
	
	//UNARY Servicio 1
	@Override  
	public void registrarVenta(VentaRequest request, StreamObserver<RestoProductoReply> responseObserver) {
		String id = request.getIdProducto();
		int cantidad = request.getCantidad();
	
		mapaProductos.put(id, mapaProductos.get(id) - cantidad);
		
		
		for(Map.Entry<String, Integer> entry : this.mapaProductos.entrySet()) {
			this.v.addText("Server: Producto " + entry.getKey() + " quedan " + entry.getValue());
		}
		
		RestoProductoReply res = RestoProductoReply.newBuilder().setResto(mapaProductos.get(id)).build();
		
		//Mandamos la respuesta
		responseObserver.onNext(res);
		responseObserver.onCompleted();
	}
	
	@Override //Server streaming SERVICIO 2
	public void bajoStock(StockRequest request, StreamObserver<ProductosReply> responseObserver) {
		int umbral = request.getUmbral();
		
		for(Map.Entry<String, Integer> entry : this.mapaProductos.entrySet()) {
			this.v.addText("Server: Producto " + entry.getKey() + " quedan " + entry.getValue());
			if (entry.getValue() < umbral) {
				// Enviamos la respuesta
				ProductosReply res = ProductosReply.newBuilder().setIdProducto(entry.getKey()).build();
				responseObserver.onNext(res);
			}
		}
		
		responseObserver.onCompleted();
		
	}
	
	@Override //BIDIRECTIONAL STREAMING SERVICIO 3
	public StreamObserver<DameStockRequest> dameStockR(StreamObserver<DameStockReply> responseObserver) {
		return new StreamObserver<DameStockRequest>() {
			
			@Override
			public void onNext(DameStockRequest value) {
				String id = value.getIdProducto();
				int cantidad = mapaProductos.get(id);

				DameStockReply res = DameStockReply.newBuilder().setIdProducto(id).setCantidad(cantidad).build();
				
				responseObserver.onNext(res);
			}

			@Override
			public void onError(Throwable t) {
				v.addText("Error en el servidor: " + t.getMessage());
			}

			@Override
			public void onCompleted() {
				
				responseObserver.onCompleted();
				v.addText("Finalizando el servicio de stock");
			}
		};
	}
	
}
