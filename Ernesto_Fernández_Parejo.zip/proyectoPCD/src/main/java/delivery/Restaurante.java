package delivery;

import bank.*;
import pcd.util.ColoresConsola;
import pcd.util.Traza;

 public class Restaurante {
	private String nombre;					// nombre del restaurante
	private Account account;				// cuenta bancaria para registrar la recaudaci�n
	private Cocina cocina; 					// la cocina de este restaurante
	private ControlMoteros controlMoteros;  // los moteros de este restaurante
	private Cargador cargador;
	
	public Restaurante (Account _ac, String _nombre, int _numeroMoteros) {
		account = _ac;
		nombre = _nombre;
		controlMoteros = new ControlMoteros (this, Config.numeroMoteros);
		cocina = new Cocina (this);
		Traza.traza(ColoresConsola.GREEN_BOLD_BRIGHT, 1,"Creando restaurante: "+nombre);
		
		//Cada restaurante tiene su propia estación de carga
		this.cargador = new Cargador(new SincronizadorInicialCargador());
		HiloCargador hc = new HiloCargador(cargador);
		hc.start();
	}
	
	public Cargador getCargador() {
		return cargador;
	}

	public String getNombre () {
		return nombre;
	}
	
	public double getBalance (){
		return account.getBalance();
	}
	
	public Account getAccount () {
		return account;
	}
	
	public synchronized void tramitarPedido (Pedido _p) { //version 2 synchronized
		Pedido p =_p;
		// Tramitar un pedido es:
		account.deposit(p.getPrecioPedido()); 	// a�adir la cantidad abonada a la cuenta del banco
		controlMoteros.MoteroLibre(); 			//version3
		cocina.cocinar(p);						// mandar el pedido a cocina
		controlMoteros.enviarPedido(p);			// una vez cocinado, mandarlo a los moteros para que uno lo coja
	}
}
