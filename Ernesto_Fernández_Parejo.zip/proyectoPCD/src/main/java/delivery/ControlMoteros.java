package delivery;

import java.util.LinkedList;
import java.util.List;



public class ControlMoteros {
	private int moterosLibres;
	private Restaurante r;
	private List<Pedido> pedidosRepartir = new LinkedList<Pedido>();
	private Todos todos = new Todos();
	
	
	public ControlMoteros (Restaurante _r, int moterosLibres) {
		//Entrega 6 parte (e)
		switch(Config.comoLanzarMoteros){ //Hay que cambiar el valor de "comoLanzarMoteros" para probarlo
		case 0:
				this.todos = new Todos();
				break;
				
		case 1:
				this.todos = new TodosCyclicBarrier();
				break;
		}
		r=_r;
		this.moterosLibres = moterosLibres;
		
		
		for(int i = 0; i < this.moterosLibres; i++) {
			new Motero(i, r, this, todos).start();
			
		}
	}
	
	//Si no hay motero libre, manda el hilo a dormir
	public synchronized void MoteroLibre() {
		System.out.println("Reservando motero para restaurante" + r.getNombre());
		while(this.moterosLibres==0) {
			try {
				System.out.println("Esperando a que haya un motero libre...");
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		//Cuando llegue a este punto signidfica que se ha liberado un motero 
		this.moterosLibres--;
	}

	public synchronized void enviarPedido (Pedido p) {
		
		try {
			Thread.sleep(500); // Simulamos que tarda 0,5 segundos en repartir
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		//El pedido que se esta repartiendo lo metemos en la lista de pedidos.
		this.pedidosRepartir.add(p);
		notifyAll();
	}
	
	public synchronized Pedido getPedido() {
		//Mientras que no haya pedidos para repartir
		while(this.pedidosRepartir.isEmpty()) {
			System.out.println("Motero esperando pedido...");
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return this.pedidosRepartir.remove(0);
	}
	
	public synchronized void moteroRegresa() {
		this.moterosLibres++;
		notifyAll();
	}

}
