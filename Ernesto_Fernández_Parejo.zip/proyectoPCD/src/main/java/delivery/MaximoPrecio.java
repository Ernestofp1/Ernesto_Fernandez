package delivery;

import java.util.List;
import java.util.concurrent.Callable;

public class MaximoPrecio implements Callable<Pedido>{

	private List <Pedido> listaPedidos; 
	
	public MaximoPrecio(List<Pedido> lp) {
		this.listaPedidos = lp;
	}

	@Override
	public Pedido call() throws Exception {
		Pedido mayor = this.listaPedidos.get(0);
		
		for(Pedido pedido : listaPedidos) {
			if(pedido.getPrecioPedido() > mayor.getPrecioPedido()) {
				mayor = pedido;
			}
		}
		return mayor;
	}
	

}
