package delivery;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

//Entrega 6 parte (e)
public class TodosCyclicBarrier extends Todos{
	private final CyclicBarrier barrera;
	
	public TodosCyclicBarrier() {
		this.barrera = new CyclicBarrier(Config.numeroMoteros, new Runnable() {
			
			@Override
			public void run() {
				System.out.println("Ya estan todos los moteros, pueden salir a repartir CB.");	
			}
		});
	}

	public void estamosTodos() {
		System.out.println("El motero llega al restaurante CB.");
		try {
			barrera.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (BrokenBarrierException e) {
			e.printStackTrace();
		}
		System.out.println("Los moteros salen del restaurante CB");
	}
}
