//Clase con nombre Robot change
package delivery;

public class Robot extends Thread{
	private Contenedor contenedor;
	private int idProducto;

	public Robot(Contenedor contenedor, int idProducto) {
		this.contenedor = contenedor;
		this.idProducto = idProducto;
	}
	
	
	@Override
	public void run() {
		try {
			while(true) {
				this.contenedor.ponerProducto(this.idProducto);
				Thread.sleep(500);
			}
		} 
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
