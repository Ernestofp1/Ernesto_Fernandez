package delivery;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.swing.GroupLayout.ParallelGroup;

//Version 1

public class PedidosConcurrente implements Runnable{

	private Pedido p;
	private List<Restaurante> listaRestaurante;
	
	public PedidosConcurrente(Pedido p, List <Restaurante> listaRestaurante) {
		this.p = p;
		this.listaRestaurante = listaRestaurante;
		
	}
	
	//Version 6
	public static void lanzarPedidos(List<Pedido> listaPedidos, List<Restaurante> listaRestaurante) {
		switch (Config.comoLanzarPedidos) {
		case 0: 
			List<Thread> listaHilosPedidos = new LinkedList<Thread>();
			
			
			for (Pedido p : listaPedidos) {
				//version 6
				PedidosConcurrente pc = new PedidosConcurrente (p, listaRestaurante);
				Thread hiloPedido = new Thread(pc);
				listaHilosPedidos.add(hiloPedido);
				hiloPedido.start();
			}
			
			for(Iterator iterator  = listaHilosPedidos.iterator(); iterator.hasNext();) {
				Thread t = (Thread) iterator.next();
				try {
				//El join es para esperar a que un hilo termine de ejecutarse antes de seguir con otro
				t.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			break;
		case 1: //Executor VERSION 6
			int numHilos = Runtime.getRuntime().availableProcessors();
			ExecutorService ejecutor = Executors.newFixedThreadPool(numHilos);
			
			for (Pedido p : listaPedidos) {
				ejecutor.execute(new PedidosConcurrente(p, listaRestaurante));
			}
			
			ejecutor.shutdown();
			//Esperar a que los hilos hayan termiando  de ejecutarse
			try {
				if(!ejecutor.awaitTermination(1,TimeUnit.DAYS)) {
					System.out.println("Algunos hilos no han terminado al cabo de un dia");
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
			break;
			
		case 2:
			listaPedidos.stream()
			.parallel()
			.forEach(p->listaRestaurante.get(p.getRestaurante()).tramitarPedido(p)); // Procesa cada Pedido
			break;
		}
	}
	
	@Override
	public void run(){
		Restaurante r;
		r = listaRestaurante.get(p.getRestaurante()); //Obtengo el que restaurante que tiene asignado el pedido
		r.tramitarPedido(p);
	}
}
