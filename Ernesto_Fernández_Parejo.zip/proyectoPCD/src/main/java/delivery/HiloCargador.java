package delivery;

public class HiloCargador extends Thread{
	private final Cargador cargador;
	
	public HiloCargador (Cargador cargador) {
		this.cargador = cargador;
	}
	
	public void run() {
		try {
			while(true) {
				cargador.cargarMoto();
			}	
		} 
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
