package delivery;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

import pcd.util.Traza;

public class MyDelivery {
	
	public MyDelivery () {
		// para facilitar las trazas
		Traza.setNivel(Config.modoTraza);
		
		// Creando los restaurantes
		CadenaRestaurantes cadenaRestaurantes = null;
		cadenaRestaurantes = new CadenaRestaurantes (Config.numeroRestaurantes);
		cadenaRestaurantes.crearRestaurantes();

		// CARGAR PEDIDOS DE FICHERO
		// Obtenemos una lista de pedidos
		List<Pedido> lp;
		lp = new LinkedList<>();
		lp = Pedido.pedidosDesdeFichero ("C:\\Users\\Ernesto\\Desktop\\UNI 24-25\\Segundo cuatri\\PCD\\WorkSpace\\proyectoPCD\\pedidos\\pedidos2.bin"); 
		
		// LANZAR PEDIDOS
		// Los estamos lanzando secuencialmente
		long initialTime = new Date().getTime();
		LinkedList<Restaurante> restaurantsList = cadenaRestaurantes.getRestaurantes();
		
		//Version6 (a)
		PedidosConcurrente.lanzarPedidos(lp, restaurantsList);
		
		//VERSION 6 (c)
		//Creamos un ejecutor para que se ejecute el Callable.
		//Escogeremos newSingleThreadExecutor() porque se va a tratar de un solo hilo
		ExecutorService ejecutor = Executors.newSingleThreadExecutor();
		
		//Creamos el Callable para calcular el pedido mas caro en su funcion call
		MaximoPrecio callable = new MaximoPrecio(lp);
		
		Future<Pedido> resultado = ejecutor.submit(callable);
		
		List <Pedido> listaPedidosMayores;
		
		//Version6 (d)
		ForkJoinPool fjp = new ForkJoinPool();
		FiltroPedido fp = new FiltroPedido(lp, 0, lp.size());
		listaPedidosMayores = fjp.invoke(fp); //Me da error aqui
		
		System.out.println("Los pedidos menores que 12 euros son: ");
		for(Pedido p : listaPedidosMayores) {
			p.print();
		}
		
		
		Pedido pedidoMasCaro;
		try {
			pedidoMasCaro = resultado.get();
			System.out.println("El pedido mas caro es: ");
			pedidoMasCaro.print();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
		finally {
			//Importante terminar el ejecutor
			ejecutor.shutdown();
		}
		
		//Version 7 
		//(a)
		lp.stream().parallel()
				.filter(p->p.getPrecioPedido() < 7)
				.map(p->p.getId() + " " + p.getPrecioPedido())
				.forEach(s->System.out.println(s));
		
		// (b)
		lp.stream()
			.parallel()
			.map(p->p.getPrecioPedido())
			.reduce((p, b) ->p > b ? p:b)
			.ifPresent(p->System.out.println(p));
		
		//Version 7 Punto (e)
		restaurantsList.stream()
		.parallel()
		.forEach(r->System.out.println(("\nAuditoria Restaurante " + r.getNombre() + " " + r.getBalance())));
		
		System.out.println ("\nAuditoria Cadena: "+ cadenaRestaurantes.getBank().audit(0, Config.numeroRestaurantes));
		
		System.out.println ("Tiempo total invertido en la tramitaci�n: "+(new Date().getTime() - initialTime));
		
		//Apartado (c)
		lp.stream()
			.parallel()
			.filter(p ->"Berna, 11".contains(p.getDireccion()))
			.findAny()
			.ifPresent(d->System.out.println("encontrado" + d));
	}

	public static void main(String[] args) {
		new MyDelivery();
	}
}
