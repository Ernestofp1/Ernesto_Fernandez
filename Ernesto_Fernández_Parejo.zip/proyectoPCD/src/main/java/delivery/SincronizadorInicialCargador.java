package delivery;

import java.util.concurrent.CountDownLatch;

public class SincronizadorInicialCargador {
	private final CountDownLatch latch = new CountDownLatch(Config.numeroMoteros);
	private boolean desbloqueado = false;
	
	public void esperarMoteros() {
		if(this.desbloqueado) {
			System.out.println("La estacion de carga esta esperando a los primeros moteros");
		try {
			latch.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.desbloqueado = true;
		System.out.println("Ya han llegado todos los moteros. Encedemos la estacion de carga");
		}		
	}
	public void notificarLlegada() {
		if(this.latch.getCount()>0) {
			this.latch.countDown();
			System.out.println("El motero llego por primera vez a la estación de carga");
		}
	}
}
