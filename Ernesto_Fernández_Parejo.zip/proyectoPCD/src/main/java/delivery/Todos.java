package delivery;

import java.util.concurrent.Semaphore;

public class Todos {
	private final int totalMoteros = Config.numeroMoteros;
	private int esperando = 0;
	private final Semaphore barrera = new Semaphore (0);
	private final Semaphore mutex = new Semaphore (1);
	
	public void estamosTodos() throws InterruptedException{
		mutex.acquire();
		
			this.esperando++;
		
			System.out.println("En este momento hay" + this.esperando + " moteros esperando");
		
			
				if (esperando == totalMoteros) {
					System.out.println("Los moteros ya pueden salir del restaurante ");
					this.barrera.release(this.totalMoteros);
					this.esperando = 0;
				}
		
		mutex.release();
		
		barrera.acquire(); //Esperar hasta que se junten X personas
	}
}
