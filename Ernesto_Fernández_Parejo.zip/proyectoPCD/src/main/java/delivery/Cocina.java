package delivery;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import pcd.util.ColoresConsola;
import pcd.util.Traza;
import usuario.MiUsuario;

public class Cocina {
	private Restaurante r;
	private List <Contenedor> listaContenedores;
	private LinkedBlockingQueue<Integer> contenedorLechuga;
	
	MiUsuario cliente = new MiUsuario("localhost", 9093);
	
	public Cocina (Restaurante _r) 
	{
		r=_r;
		this.listaContenedores = new ArrayList<Contenedor>();
		this.contenedorLechuga = new LinkedBlockingQueue<Integer> (2); //Maximo de lechugas que se pueden almacenar
		
		Contenedor contPan = new Contenedor(3);
		Contenedor contPollo = new Contenedor(1);
		
		this.listaContenedores.add(contPan);
		this.listaContenedores.add(contPollo);
		
		Robot robotPan = new Robot(contPan, 3);
		Robot robotPollo = new Robot(contPollo, 1);
		RobotLechuga robotLechuga = new RobotLechuga(contenedorLechuga);
		
		robotPan.start();
		robotPollo.start();
		robotLechuga.start();
	}
	
	//Manda a dormir el hilo para simular que esta cocinando*
	public void cocinar (Pedido p) 
	{
		List <Producto> productos  = p.getProductos();
		Traza.traza(ColoresConsola.GREEN, 2, "Cocinando el pedido: "+p.printConRetorno());
		
		try {
			for(Producto producto : productos) {
				if(producto.getId().equals("0")) {
					System.out.println("Se esta cocinando homburguesa de pollo");
					for(Contenedor contenedor : this.listaContenedores) {
						contenedor.quitarProducto();
						
					}
					//Extrae de forma bloqueante un elemento de la cola.
					//Si esta vacia, se bloquea hasta que alguien despierta
					this.contenedorLechuga.take();
				}
				
				cliente.ejecutarRegistrarVenta(producto.getId(), producto.getCantidad());
				
			}
			//Simulamos que se est� cocinando
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}