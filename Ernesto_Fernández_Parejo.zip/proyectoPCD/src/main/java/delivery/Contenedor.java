package delivery;

import java.util.concurrent.locks.*; //--------

public class Contenedor 
{
	private int[] cesto; //----
	private int cantidad = 0;	
	
	private final Lock lock = new ReentrantLock();
	private Condition lleno = lock.newCondition();
	private Condition vacio = lock.newCondition();
	
	public Contenedor (int capacidad) {
		this.cesto = new int[capacidad];
	}
	
	public void ponerProducto(int idProducto) throws InterruptedException 
	{
		lock.lock();
		try {
			while(this.cantidad==this.cesto.length) {
				System.out.println("El contenedor" + this.cesto.length + "esta lleno...");
				lleno.await();
			}
			this.cesto[this.cantidad++] = idProducto;
			System.out.println("Se ha agragado el producto " + idProducto + "al contenedor"); //----------
			vacio.signal();
		}
		finally {
			lock.unlock();
		}
	}
	
	public int quitarProducto() throws InterruptedException 
	{
		lock.lock();
		try {
			while(this.cantidad == 0) {
				System.out.println("Contenedor vacio...");
				vacio.await();
			}
			int idProducto = this.cesto[--cantidad];
			System.out.println("El producto" + idProducto + "ha sido retirado del contendeor");
			lleno.signal();
			return idProducto;
		}
		finally {
			lock.unlock();
		}
	}
}
