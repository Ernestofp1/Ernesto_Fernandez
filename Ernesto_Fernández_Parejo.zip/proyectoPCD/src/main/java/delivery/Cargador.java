package delivery;

import java.util.concurrent.Semaphore;

public class Cargador {
	private final Semaphore moterosEsperando = new Semaphore(0);
	private final Semaphore moteroCargado = new Semaphore (0);
	private final SincronizadorInicialCargador sincronizador;
	
	public Cargador(SincronizadorInicialCargador sincronizador) {
		this.sincronizador = sincronizador;
	}
	
	//Espera a que llegue un motero
	public void esperarMotero() throws InterruptedException{
		System.out.println("Un motero llega a la zona de carga");
		
		sincronizador.notificarLlegada();
		
		this.moterosEsperando.release(); //Avisa al cargador
		this.moteroCargado.acquire(); //Espera a que el cargador lo haya rellenado
		System.out.println("La moto ha sido cargada");
	}
	
	public void cargarMoto() throws InterruptedException {
		sincronizador.esperarMoteros();
		
		this.moterosEsperando.acquire(); //Espera hasta que haya moteros que quieran cargar la moto
		System.out.println("El cargador esta cargando la moto...");
		this.moteroCargado.release(); //Entrega la moto cargada
	}
}
