package delivery;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.RecursiveTask;

public class FiltroPedido extends RecursiveTask<List<Pedido>>{

	private static final long serialVersionUID = 1L;
	private List<Pedido> listaPedidos;
	private int inicio, fin;
	
	public FiltroPedido(List <Pedido> listaPedidos, int inicio, int fin) {
		this.listaPedidos = listaPedidos;
		this.inicio = inicio;
		this.fin = fin;
	}
	
	@Override
	protected List<Pedido> compute() 
	{
		if(this.fin - this.inicio <= Config.numeroDivisiones) {
			List <Pedido> listaPedidosMenores = new ArrayList<Pedido>();
			for(Pedido p : this.listaPedidos) {
				if(p.getPrecioPedido() > 12) {
					listaPedidosMenores.add(p);
				}
			}
			return listaPedidosMenores;
		}
		
		else {
			int medio = (inicio+fin)/2;
			FiltroPedido izquierda = new FiltroPedido(listaPedidos, this.inicio, medio);
			FiltroPedido derecha = new FiltroPedido(listaPedidos, medio, this.fin);
			izquierda.fork(); //Lanza la ejecución de la tarea en un hilo de FrokJoinPool, para que se pueda ejecutar en paralelo.
			List <Pedido> resDerecha = derecha.compute();
			List <Pedido> resIzquierda = izquierda.compute();
			resIzquierda.addAll(resDerecha);
			return resIzquierda;
		}
	}

}