package delivery;
public enum Canal {
	// Canales por los que pueden venir pedidos (CC es Call Center)
	Web,Mobile,CC,Glovo,JustEat,UberEats,Deliveroo
}
