package delivery;

import pcd.util.ColoresConsola;
import pcd.util.Traza;
import pcd.util.Ventana;

//Version 3

public class Motero extends Thread{
	private int id;
	private Restaurante r;
	private Pedido repartiendo;
	private ControlMoteros CM;
	private Todos todos; 
	private int contadorPedidos;
	
	Ventana v;
	static int posicionVentana = 10;
	
	public Motero(int id, Restaurante r, ControlMoteros cM, Todos todos) 
	{
		this.todos = todos;
		this.id = id;
		this.r = r;
		CM = cM;
		
		this.contadorPedidos = 0;
		
		// Creamos una ventana para los mensajes de este objeto.
				v =  new Ventana ("Control Moteros - "+r.getNombre(), posicionVentana,10);
				posicionVentana+=250;
	}
	
	//V3
	public void repartir()
	{
		this.repartiendo = CM.getPedido();
		v.addText("REPARTIENDO PEDIDO : "+this.repartiendo.getId());
		Traza.traza(ColoresConsola.RED,1 , "Motero: " + r.getNombre() + " del Restaurante " + this.id + "reparte el pedido" + this.repartiendo.getId());
		//System.out.println("El motero" + this.id + "del reestaurante" + this.restaurante.getNombre() + " reparte el pedido" + repartiendo.getId());
		
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	//V3
	public void volver() 
	{
		System.out.println("El motero " + this.id + " del reestaurante " + this.r.getNombre() + " reparte el pedido " + repartiendo.getId());
		this.CM.moteroRegresa();
		this.contadorPedidos ++;
	}
	
	@Override
	public void run() 
	{
		while (true){
			try {
				todos.estamosTodos();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			repartir();
			volver();
			if(this.contadorPedidos%2 == 0) {
				try {
					this.r.getCargador().esperarMotero();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
