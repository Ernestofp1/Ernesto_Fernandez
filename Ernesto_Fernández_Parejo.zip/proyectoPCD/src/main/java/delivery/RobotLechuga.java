package delivery;

import java.util.concurrent.LinkedBlockingQueue;

public class RobotLechuga extends Thread{
	private LinkedBlockingQueue<Integer> contenedorLechuga;
	
	public RobotLechuga (LinkedBlockingQueue<Integer> contenedorLechuga) {
		this.contenedorLechuga = contenedorLechuga;
	}
	
	@Override
	public void run() {		
			try {
				while(true) {
					this.contenedorLechuga.put(111);
					System.out.println("Se ha metido una nueva lechuga en el contenedor");
					Thread.sleep(500);
				}
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			}
	}
}
