package server;

import java.io.IOException;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import pcd.util.Ventana;
import servicio.MiServicio;

public class MiServer {

	public static void main(String[] args) throws IOException, InterruptedException{
		Ventana v = new Ventana ("Servidor", 30, 30);
		
		Server server = ServerBuilder
				.forPort(9093)
				.addService(new MiServicio(v))
				.build();
		
		server.start();
		v.addText("Acabamos de iniciar el servidor en el puerto 50051");
		server.awaitTermination();
	}

}

